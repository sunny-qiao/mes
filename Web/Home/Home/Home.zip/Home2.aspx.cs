﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PL.Base;
using PL.Server.Core.Entity;

public partial class Home_Home_Home2 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string flowImage = EciServer.UserServer().prFlowImage;
  
            if (flowImage.HasValue())
            {
                string path = Server.MapPath("~/Samples/Flow/" + flowImage);

                if (System.IO.File.Exists(path))
                {
                    imgFlow.Visible = true;
                    imgFlow.Src = "../../Samples/Flow/" + flowImage;
                }
                else
                {
                    imgFlow.Visible = false;
                }
            }
        }
    }
}